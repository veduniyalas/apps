package com.example.app;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Single extends Activity {
	String rank;
	String country;
	String population;
	String flag;
	String position;
	ImageLoader imageLoader = new ImageLoader(this);
	SharedPreferences sharedpreferences;
	 public static final String MyPREFERENCES = "MyPrefs" ;
	 
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_single);
		
		 sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
		 
		 final ImageView added = (ImageView) findViewById(R.id.added);
		 added.setVisibility(View.INVISIBLE);
		 added.getLayoutParams().height = 0;
		 
		Intent i = getIntent();
		// Get the result of rank
		rank = i.getStringExtra("rank");
		// Get the result of country
		country = i.getStringExtra("country");
		// Get the result of population
		population = i.getStringExtra("population");
		// Get the result of flag
		flag = i.getStringExtra("flag");

		// Locate the TextViews in singleitemview.xml 
		TextView txtrank = (TextView) findViewById(R.id.rank);
		TextView txtcountry = (TextView) findViewById(R.id.country);
		TextView txtpopulation = (TextView) findViewById(R.id.population);
		
		TextView txtcountrylabel = (TextView) findViewById(R.id.countrylabel);
		txtcountrylabel.setTextColor(Color.parseColor("#DF1A33"));
		
		TextView txtranklabel = (TextView) findViewById(R.id.ranklabel);
		txtranklabel.setTextColor(Color.parseColor("#DF1A33"));
		
		TextView populationlabel = (TextView) findViewById(R.id.populationlabel);
		populationlabel.setTextColor(Color.parseColor("#DF1A33"));
		
		// Locate the ImageView in singleitemview.xml
		ImageView imgflag = (ImageView) findViewById(R.id.flag);

		// Set results to the TextViews
		txtrank.setText(rank);
		txtcountry.setText(country);
		txtpopulation.setText(population);

		// Capture position and set results to the ImageView
		// Passes flag images URL into ImageLoader.class
		imageLoader.DisplayImage(flag, imgflag);
		
		
		      	 String n  = rank;
		    String added2 = sharedpreferences.getString(n, null);
		   
		  
		//------------------
		ImageView back = (ImageView) findViewById(R.id.imageViewsingle);
		

        back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
				 finish();
			}
            
        });
       
        
        final ImageView orderbtn = (ImageView) findViewById(R.id.orderbtn);
        
        if(added2!=null)
		   {
			   orderbtn.setVisibility(View.INVISIBLE);
	              orderbtn.getLayoutParams().height = 0;
	              
	            
	     		 added.setVisibility(View.VISIBLE);
	     		 added.getLayoutParams().height = 60;
		   }
        
        orderbtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
           	 String n  = rank;
             
             SharedPreferences.Editor editor = sharedpreferences.edit();

              editor.putString(n, n);
           
              editor.commit();
              Toast.makeText(Single.this,"Added to cart.",Toast.LENGTH_SHORT).show();
              orderbtn.setImageResource(R.drawable.added);
       
              orderbtn.setVisibility(View.INVISIBLE);
              orderbtn.getLayoutParams().height = 0;
              
            
     		 added.setVisibility(View.VISIBLE);
     		 added.getLayoutParams().height = 60;
			}

			
            
        });
        
       
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch(item.getItemId()) {
	    case R.id.cart:
	        Intent intent = new Intent(this, Cart.class);
	        this.startActivity(intent);
	        break;
	    case R.id.menu:
	    	Intent intent1 = new Intent(this, Umenu.class);
	        this.startActivity(intent1);
	        break;
	    default:
	        return super.onOptionsItemSelected(item);
	    }

	    return true;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.single, menu);
		return true;
	}

}
