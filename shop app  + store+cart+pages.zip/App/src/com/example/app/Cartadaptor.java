package com.example.app;

import java.util.ArrayList;
import java.util.HashMap;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.app.ImageLoader;

public class Cartadaptor extends ListViewAdapter {

	public Cartadaptor(Context context,
			ArrayList<HashMap<String, String>> arraylist) {
		super(context, arraylist);
		this.context = context;
		data = arraylist;
		imageLoader = new ImageLoader(context);
	}
	
	
	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		// Declare Variables
		TextView id;
		TextView name;
		final TextView price;
		ImageView cimage;
		ImageView removeicon;

		inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View itemView = inflater.inflate(R.layout.cart_list, parent, false);
		// Get the position
		resultp = data.get(position);

		// Locate the TextViews in listview_item.xml
		
		name = (TextView) itemView.findViewById(R.id.textView2);
		price = (TextView) itemView.findViewById(R.id.textView3);

		// Locate the ImageView in listview_item.xml
		cimage = (ImageView) itemView.findViewById(R.id.imageView1);
		removeicon = (ImageView) itemView.findViewById(R.id.remove);

	
	
		name.setText(resultp.get(Cart.name));
		price.setText(resultp.get(Cart.price));
		imageLoader.DisplayImage(resultp.get(Cart.image), cimage);
		
		removeicon.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				String str = resultp.get(Cart.id);
				price.setText(resultp.get(Cart.id));
				SharedPreferences preferences = context.getSharedPreferences ("MyPrefs", android.content.Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = preferences.edit();
				editor.remove(str);
				editor.commit();
				resultp = data.get(position);
				remove(resultp);
			}

			private void remove(HashMap<String, String> resultp) {
				data.remove(resultp);
				Cartadaptor.this.notifyDataSetChanged();
				Cartadaptor.this.notifyDataSetInvalidated();
			}
		});
	
		return itemView;
	}

}
