package com.example.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


public class MainActivity extends Activity {
	// Declare Variables
	JSONObject jsonobject;
	JSONArray jsonarray;
	ListView listview;
	ListViewAdapter adapter;
	ProgressDialog mProgressDialog;
	ArrayList<HashMap<String, String>> arraylist;
	static String RANK = "rank";
	static String COUNTRY = "country";
	static String POPULATION = "population";
	static String FLAG = "flag";
	EditText editsearch;
	String answer;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_main);
	// Execute DownloadJSON AsyncTask 
	
	new DownloadJSON().execute();
				 
	}
	
	
	public final boolean isInternetOn() {
        
        getBaseContext();
		// get Connectivity Manager object to check connection
        ConnectivityManager connec =  
                       (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
         
           // Check for network connections
            if ( connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTED ||
                 connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTING ||
                 connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTING ||
                 connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTED ) {
                
                // if connected with internet
                 
                Toast.makeText(this, " Connected ", Toast.LENGTH_LONG).show();
                return true;
                 
            } else if ( 
              connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.DISCONNECTED ||
              connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.DISCONNECTED  ) {
               
                Toast.makeText(this, " Not Connected ", Toast.LENGTH_LONG).show();
                return false;
            }
          return false;
        }

	
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main_actions, menu);
 
        return super.onCreateOptionsMenu(menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch(item.getItemId()) {
	    case R.id.cart:
	        Intent intent = new Intent(this, Cart.class);
	        this.startActivity(intent);
	        break;
	    case R.id.menu:
	    	Intent intent1 = new Intent(this, Umenu.class);
	        this.startActivity(intent1);
	        break;
	    default:
	        return super.onOptionsItemSelected(item);
	    }

	    return true;
	}
	
	// DownloadJSON AsyncTask
	public class DownloadJSON extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			 isInternetOn();
			// Create a progressdialog
			mProgressDialog = new ProgressDialog(MainActivity.this);
			// Set progressdialog title
			
			mProgressDialog.setIcon(R.drawable.uni);
			mProgressDialog.setMessage("Loading Data ...");
			mProgressDialog.setIndeterminate(false);
			// Show progressdialog
			mProgressDialog.show();
		}

		@Override
		protected Void doInBackground(Void... params) {
			// Create an array
			arraylist = new ArrayList<HashMap<String, String>>();
			// Retrieve JSON Objects from the given URL address
			jsonobject = JSONfunctions
					.getJSONfromURL("http://monthlypaymarketing.com/json/json.php");

			try {
				// Locate the array name in JSON
				jsonarray = jsonobject.getJSONArray("all");

				for (int i = 0; i < jsonarray.length(); i++) {
					HashMap<String, String> map = new HashMap<String, String>();
					jsonobject = jsonarray.getJSONObject(i);
					// Retrive JSON Objects
					map.put("rank", jsonobject.getString("id"));
					map.put("country", jsonobject.getString("name"));
					map.put("population", jsonobject.getString("price"));
					map.put("flag", jsonobject.getString("image"));
					// Set the JSON Objects into the array
					arraylist.add(map);
				}
			} catch (JSONException e) {
				Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void args) {
			// Locate the listview in listview_main.xml
			listview = (ListView) findViewById(R.id.listView);
			// Pass the results into ListViewAdapter.java
			adapter = new ListViewAdapter(MainActivity.this, arraylist);
			// Set the adapter to the ListView
			listview.setAdapter(adapter);
			// Close the progressdialog
			editsearch = (EditText) findViewById(R.id.inputSearch);
			editsearch.addTextChangedListener(new TextWatcher() {

				@Override
				public void afterTextChanged(Editable arg0) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void beforeTextChanged(CharSequence arg0, int arg1,
						int arg2, int arg3) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void onTextChanged(CharSequence s, int start,int before, int count) {
					// TODO Auto-generated method stub
					 ArrayList<HashMap<String, String>> arrayTemplist= new ArrayList<HashMap<String,String>>();
					 String searchString =editsearch.getText().toString();
					 searchString= searchString.toLowerCase(Locale.getDefault());
					
					 if(searchString.length()>0)
			            {
					 for (int i = 0; i < arraylist.size(); i++)
	                    {
						 
						 String  currentString =arraylist.get(i).get("country");
						 currentString= currentString.toLowerCase(Locale.getDefault());
	                       // if (currentString.equalsIgnoreCase(searchString))
	                        	if (currentString.contains(searchString))
	                        {
	                            arrayTemplist.add(arraylist.get(i));
	                        }
	                    }
					/* String  currentString =arraylist.get(0).get("country");
					
				  Toast.makeText(getApplicationContext(), currentString ,Toast.LENGTH_LONG).show();  
					 */
					 
					 adapter = new ListViewAdapter(MainActivity.this, arrayTemplist);
	                    listview.setAdapter(adapter);
				}
					 else
					 {
						 adapter = new ListViewAdapter(MainActivity.this, arraylist);
			                listview.setAdapter(adapter);
						 
					 }
				}
			
			});
			
			
			mProgressDialog.dismiss();
		}
	}
}